eventSetClasspath = { rootLoader ->
	rootLoader.addURL(new URL("http://repo1.maven.org/maven2/org/apache/geronimo/specs/geronimo-jms_1.1_spec/1.1/geronimo-jms_1.1_spec-1.1.jar"))
}