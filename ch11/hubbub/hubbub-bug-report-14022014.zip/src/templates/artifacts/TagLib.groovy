@artifact.package@class @artifact.name@ {
    static defaultEncodeAs = 'html'
    //static encodeAsForTags = [tagName: 'raw']
}
