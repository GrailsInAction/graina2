@artifact.package@import grails.transaction.Transactional

@Transactional
class @artifact.name@ {

    def serviceMethod() {

    }
}
