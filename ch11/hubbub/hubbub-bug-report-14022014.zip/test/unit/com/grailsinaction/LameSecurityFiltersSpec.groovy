package com.grailsinaction

import grails.test.mixin.Mock
import spock.lang.Specification

@Mock(LameSecurityFilters)
class LameSecurityFiltersSpec extends Specification {

	def setup() {
	}

	def cleanup() {
	}

	void "test something"() {
	}
}