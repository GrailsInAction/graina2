class TwitterAuthController extends com.the6hours.grails.springsecurity.twitter.TwitterAuthController {

}