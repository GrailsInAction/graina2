package com.grailsinaction

class ProfileController {
    static scaffold = true
}
