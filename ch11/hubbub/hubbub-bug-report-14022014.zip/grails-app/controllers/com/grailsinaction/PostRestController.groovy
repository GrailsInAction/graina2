package com.grailsinaction

import grails.converters.JSON
import grails.rest.RestfulController

class PostRestController extends RestfulController {
    static responseFormats = ["json", "xml"]

    PostRestController() {
        super(Post)
    }
}
