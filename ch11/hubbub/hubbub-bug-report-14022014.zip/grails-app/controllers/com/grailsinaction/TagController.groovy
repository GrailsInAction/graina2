package com.grailsinaction

class TagController {
    static scaffold = true
}
