// Place your Spring DSL code here
import com.grailsinaction.MarshallerRegistrar

beans = {
    hubbubMarshallerRegistrar(MarshallerRegistrar)
}
