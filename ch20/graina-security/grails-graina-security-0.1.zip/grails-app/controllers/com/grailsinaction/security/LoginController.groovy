package com.grailsinaction.security

class LoginController {

    def index() {}
}
